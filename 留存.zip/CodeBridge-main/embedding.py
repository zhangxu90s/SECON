"""
get embeddings of different models
"""

from transformers import AutoTokenizer, AutoModel
import torch
from transformers import (RobertaModel, RobertaTokenizer)
import models.unixcoder.model
import models.cocosoda.model
import models.secon.model
import os
from torchsummary import summary
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total trainable parameters: {count_parameters(model):,}")

def get_embedding_model(n_gpu, device, model_name):
    m = None
    if "bge" in model_name:
        print("using BGE embdding model")
        m = BGE_Embedding(n_gpu, device)
    elif "unixcoder" in model_name:
        print("using unixcoder embdding model")
        m = UnixcoderEmbedding(n_gpu, device)
    elif "cocosoda" in model_name:
        print("using cocosoda embdding model")
        m = CocosodaEmbedding(n_gpu, device)
    elif "secon" in model_name:
        print("using secon embdding model")
        m = SeconEmbedding(n_gpu, device)

    return m
        
class ModelEmbedding:
    """
    base class
    """
    def __init__(self):
        self.model = None
        
    def get_embedding(self,encoded_input, is_nl):
        with torch.no_grad():
            if is_nl:
                vec = self.model(nl_inputs=encoded_input) 
            else:
                vec = self.model(code_inputs=encoded_input)
            return vec

class BGE_Embedding(ModelEmbedding):
    def __init__(self, n_gpu, device, model_path="BAAI/bge-large-en-v1.5"): 
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModel.from_pretrained(model_path)
        self.model.eval()
        if n_gpu > 1:
            self.model = torch.nn.DataParallel(self.model)
        self.model.to(device)
            
    def get_embedding(self, encoded_input,is_nl=None):
        # Compute token embeddings
        with torch.no_grad():
            model_output = self.model(**encoded_input)
            #  Perform pooling. In this case, cls pooling.
        
            sentence_embeddings = model_output[0][:, 0]
            # normalize embeddings
            sentence_embeddings = torch.nn.functional.normalize(sentence_embeddings, p=2, dim=1)
            return sentence_embeddings

        
        
class UnixcoderEmbedding(ModelEmbedding):
    def __init__(self, n_gpu, device, model_path="unixcoder-base"): 
        
        self.tokenizer = RobertaTokenizer.from_pretrained(model_path)
        model = RobertaModel.from_pretrained(model_path) 
        self.model = models.unixcoder.model.Model(model)
        self.model.eval()
        if n_gpu > 1:
            self.model = torch.nn.DataParallel(self.model)
        self.model.to(device)
        print(count_parameters(self.model))  

class SeconEmbedding(ModelEmbedding):
    def __init__(self, n_gpu, device, model_path="SECON"): 
        self.tokenizer = RobertaTokenizer.from_pretrained(model_path)
        model = RobertaModel.from_pretrained(model_path) 
        self.model = models.secon.model.Model(model)

        checkpoint_prefix = 'model.bin'
        output_dir = os.path.join(model_path, '{}'.format(checkpoint_prefix))  
        print("output_dir:",output_dir)
        model_to_load = self.model.module if hasattr(model, 'module') else self.model  
        model_to_load.load_state_dict(torch.load(output_dir))      
        self.model.eval()
        if n_gpu > 1:
            self.model = torch.nn.DataParallel(self.model)
        self.model.to(device)
        print(count_parameters(self.model))  

class CocosodaEmbedding(ModelEmbedding):
    def __init__(self, n_gpu, device, model_path="CoCoSoDa"): 
        
        self.tokenizer = RobertaTokenizer.from_pretrained(model_path)
        model = RobertaModel.from_pretrained(model_path) 
        self.model = models.cocosoda.model.Model(model)
        self.model.eval()
        if n_gpu > 1:
            self.model = torch.nn.DataParallel(self.model)
        self.model.to(device)
        print(count_parameters(self.model))  




