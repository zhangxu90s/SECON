# langs=(sql solidity cosqa)
langs=(cosqa)

models=(unixcoder cocosoda secon)

dir="./data/cross-domain"
cosqa_query_path=$dir/cosqa/cosqa-retrieval-test-500.json
cosqa_code_path=$dir/cosqa/code_idx_map.txt


sql_query_path=$dir/sql/batch_0.txt
sql_code_path=$dir/sql/batch_0.txt

solidity_query_path=$dir/solidity/batch_0.txt
solidity_code_path=$dir/solidity/batch_0.txt


for lang in "${langs[@]}"; do
    query_path="${lang}_query_path"
    query_path=${!query_path}

    code_path="${lang}_code_path"
    code_path=${!code_path}


    comment_path="$dir/${lang}/${lang}_test_comment.jsonl"

    gencode_path="$dir/${lang}/${lang}_test_gen_code.jsonl"
    paths=()

    for model in "${models[@]}"; do
        path="./vectors/cross-domain/$model/$lang/"
        paths=("$path")  
    #done 
        # Debugging information
        echo "Language: $lang"
        echo "Query Path: $query_path"
        echo "Code Path: $code_path"
        echo "Comment Path: $comment_path"
        echo "GenCode Path: $gencode_path"
        echo "Paths: ${paths[@]}"

        python ./eval.py  \
            --mode "eval"    \
            --model_name_or_path $model \
            --eval_batch_size 8 \
            --device cuda \
            --lang $lang \
            --query2code_cache_path "${paths}$lang-query.npy" \
            --query_target_code_cache_path   "${paths}$lang-code.npy" \
            --query2comment_cache_path  "${paths}$lang-query.npy" \
            --comment_cache_path   "${paths}$lang-comment.npy" \
            --gencode_target_code_cache_path "${paths}$lang-code.npy" \
            --gen_code_cache_path   "${paths}$lang-gencode.npy" \
            --query_data_file $query_path \
            --code_data_file $code_path \
            --comment_data_file $comment_path \
            --gen_code_data_file $gencode_path \
            --w1 0.65 \
            --w2 0.25 \
            --w3 0.10
    done 

done
