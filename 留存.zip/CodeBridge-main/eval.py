"""
clean version of evaluation
"""
import os
from sklearn.metrics import mean_squared_error
from transformers import AutoTokenizer, AutoModel
import torch
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler,TensorDataset
from tqdm import tqdm
import logging
import numpy as np
import argparse
import csv
import random
from text_dataset import TextDataset
import json
from transformers import AutoTokenizer, AutoModelForCausalLM

from transformers import (WEIGHTS_NAME, AdamW, get_linear_schedule_with_warmup,
                        RobertaConfig, RobertaModel, RobertaTokenizer)
from embedding import ModelEmbedding, get_embedding_model
import metric
from prettytable import PrettyTable

os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2,3' 

logger = logging.getLogger(__name__)


class ResultTable:
    def __init__(self, title):
        self.table = PrettyTable(title)       
    def add_row(self,row):
        self.table.add_row(row)
    def print_table(self):
        print(self.table)
def get_datasets(args, tokenizer,data_file, use_origin=True):
    """
    get datasets
    :param use_origin: return text dataset
    :return tokenized_dataloader:sequential dataloader for encoded input
    :return origin_dataset: origin dataset for text
    """
    tokenized_dataset = TextDataset(args, tokenizer, "tokenize", data_file)
    origin_dataset = None
    if use_origin:
        origin_dataset = TextDataset(args, tokenizer, "text", data_file)
    sampler = SequentialSampler(tokenized_dataset)
    tokenized_dataloader = DataLoader(tokenized_dataset, sampler=sampler, batch_size=args.eval_batch_size,num_workers=4)
    return tokenized_dataloader, origin_dataset


def get_embeddings(device, embedding_model,dataloader, is_nl, save_vector_path=None):
    """
    return matrix of embeddings (num, hidden_size)
    """
    vecs = []
    for batch in tqdm(dataloader):
        # batch[0]: code_input
        # btach[1]: nl_input
        if is_nl:
            inputs = batch[1].to(device)
        else:
            inputs = batch[0].to(device)

        embeds = embedding_model.get_embedding(inputs, is_nl)
        vecs.append(embeds.cpu().numpy())    
    vecs = np.concatenate(vecs,0)
    if save_vector_path:
        logger.info(f"saving query vector to {save_vector_path} {vecs.shape}")
        np.save(save_vector_path, vecs)
    return vecs
def evaluate(args,query2code_scores,query2comment_scores, code2code_scores):
    if args.mode == 'eval':
        assert args.w2 != None and args.w3 != None

        query_dataset = TextDataset(args,None,"text",args.query_data_file)
        code_dataset = TextDataset(args, None, "text",args.code_data_file)
        gen_code_dataset = TextDataset(args, None, "text", args.gen_code_data_file)
        
        nl_urls = []
        for ex in query_dataset:
            nl_urls.append(ex['url'])
        code_urls = []
        for ex in code_dataset:
            code_urls.append(ex['url'])
            
        # test different weights
        title = ["MRR","Top-1","Top-5","Top-10"]
        result_table = ResultTable(title)   
        w = [args.w1,args.w2, args.w3]
            
        res = get_results(w[0]*query2code_scores,nl_urls, code_urls) #+ w[1]*query2comment_scores + w[2]*code2code_scores
    
        result_table.add_row(res)
        result_table.print_table()
        
    
    elif args.mode == 'traverse':
        # create result table
        title = ["weights","MRR","Top-1","Top-5","Top-10"]
        result_table = ResultTable(title)   
        # traverse with different weights
        step_size = 0.01
        # traverse all the weights, where w1+w2+w3=1, with step_size
        w1_list = np.arange(0,1+step_size,step_size)
        w2_list = np.arange(0,1+step_size,step_size)
        w3_list = np.arange(0,1+step_size,step_size)
        ans_list = []
        control_ans_list = []
        for w1 in tqdm(w1_list):
            for w2 in w2_list:
                if w1 + w2 > 1:
                    continue
                for w3 in w3_list:
                    # check if the sum of w1,w2,w3 is 1
                    if w1 + w2 + w3 != 1:
                        continue
                    res = get_results(w1*query2code_scores + w2*query2comment_scores + w3*code2code_scores,nl_urls, code_urls)
                    r = ["-".join([str(round(w1,2)),str(round(w2,2)),str(round(w3,2))])] + res
                    ans_list.append(r)


        with open('traverse.csv', 'w') as f:
            writer = csv.writer(f)
            writer.writerows(ans_list)


def get_results(scores,nl_urls, code_urls):
    """
    given scores matrix(nl,cl) and labeld urls, return a list containing:
    """
    sort_ids = np.argsort(scores, axis=-1, kind='quicksort', order=None)[:,::-1] 
        
    sort_urls = [[code_urls[idx] for idx in sort_id] for sort_id in sort_ids]
   
    mrrs = metric.cal_mrr(sort_urls, nl_urls)
    recalls = metric.cal_recall(sort_urls, nl_urls)
    mrrs = [round(float(r),3) for r in list(mrrs.values())]
    # mrr10 mrr1000, hr1,hr5, hr10
    mrrs = [mrrs[5]]
    recalls = [round(float(r),3) for r in list(recalls.values())][:3]
    return mrrs + recalls
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--query_data_file", default=None, type=str,
                        help="An optional input test data file to test the MRR(a josnl file).")
    parser.add_argument("--code_data_file", default=None, type=str,
                        help="An optional input test data file to codebase (a jsonl file).")  
    parser.add_argument("--comment_data_file", default=None, type=str,
                        help="An optional input test data file to codebase (a jsonl file).") 
    parser.add_argument("--gen_code_data_file", default=None, type=str,
                        help="An optional input test data file to codebase (a jsonl file).") 
    
    parser.add_argument("--lang", default=None, type=str,
                        help="language.")

    parser.add_argument("--nl_length", default=128, type=int,
                        help="Optional NL input sequence length after tokenization.")    
    parser.add_argument("--code_length", default=256, type=int,
                        help="Optional Code input sequence length after tokenization.") 
    parser.add_argument("--eval_batch_size", default=4, type=int,
                        help="Batch size for evaluation.")
    # there're two queries embeddings maybe
    parser.add_argument("--query2code_cache_path", default=None, type=str, 
                        help="tt")
    parser.add_argument("--query2comment_cache_path", default=None, type=str, 
                        help="tt")
    parser.add_argument("--query_target_code_cache_path", default=None, type=str, 
                        help="maching query2code")
    parser.add_argument("--gencode_target_code_cache_path", default=None, type=str,help="matching gencode cache") 
    
    parser.add_argument("--comment_cache_path", default=None, type=str, 
                        help="tt")
    parser.add_argument("--gen_code_cache_path", default=None, type=str, 
                        help="tt")
    parser.add_argument("--w1", default=None, type=float, 
                        help="tt")
    parser.add_argument("--w2", default=None, type=float, 
                        help="tt")    
    parser.add_argument("--w3", default=None, type=float, 
                        help="tt")
    
    parser.add_argument("--mode",default=None, type=str,help="eval/traverse", required=True)
    
    parser.add_argument("--model_name_or_path",default=None, type=str,help="embedding/eval")
    parser.add_argument("--format",default=None, type=str,help="query/code/comment/gencode")

    parser.add_argument("--output_dir",default=None, type=str,help="embedding/eval")
    parser.add_argument("--device",default='cuda', type=str,help="embedding/eval")
    parser.add_argument("--datafile",default=None, type=str,help="embedding/eval")
    


    #print arguments
    args = parser.parse_args()
    #set log
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',level=logging.INFO )
    print(args)
    n_gpu = torch.cuda.device_count()
    print(f"n_gpu: {n_gpu}")
    
    
    if args.mode == "embedding":
        # get embeddings and store
        embedding_model=get_embedding_model(n_gpu, args.device, args.model_name_or_path)
        dataloader, _ = get_datasets(args,embedding_model.tokenizer, args.datafile, use_origin=False)
        is_nl = "query" in args.format or "comment" in args.format
        dir_path = os.path.join(
                           args.output_dir,
                           args.model_name_or_path, 
                           args.lang)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
        save_vector_path=os.path.join(dir_path,f"{args.lang}-{args.format}.npy")
        logger.info(f"getting embedding of {args.lang} {args.format}")
        logger.info(f"save vectors to {save_vector_path}, is_nl = {is_nl}")
        get_embeddings(args.device, 
                       embedding_model,
                       dataloader,
                       is_nl,
                       save_vector_path=save_vector_path
                       )
    elif args.mode == "eval":
        print("=====evaluating {}=====".format(args.lang))
        
        # test different models and settings 
        query2code_embedding = np.load(args.query2code_cache_path)
        query2comment_embedding = np.load(args.query2comment_cache_path)
        # target_code_embedding = np.load(args.code_cache_path)
        comment_embedding = np.load(args.comment_cache_path)
        gen_code_embedding = np.load(args.gen_code_cache_path)
        query_target_code_embedding = np.load(args.query_target_code_cache_path)
        gencode_target_code_embedding = np.load(args.gencode_target_code_cache_path)
          
        # query-comment + code-2code
        query2comment_scores = query2comment_embedding @ comment_embedding.T
        query2code_scores = query2code_embedding @ query_target_code_embedding.T
        code2code_scores = gen_code_embedding @ gencode_target_code_embedding.T
        
       
        evaluate(args,query2code_scores, query2comment_scores, code2code_scores,)
   